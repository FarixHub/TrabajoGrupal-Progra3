//Muestra el ticket y lo imprime.
const API_URL = "http://localhost:4000/api/productos";
const API_VENTAS = "http://localhost:4000/api/ventas";
const contenedor = document.getElementById("ticketContainer");
const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
const cliente = localStorage.getItem("clienteNombre");
const totalCompra = localStorage.getItem("totalCompra");

async function generarTicket() {
  const res = await fetch(API_URL);
  const productos = await res.json();
  let total = 0;
  const fecha = new Date().toLocaleDateString();

  const detalles = carrito.map(item => {
    const p = productos.find(prod => prod.id === item.id);
    if (!p) return "";

    // ✅ RUTA DE IMAGEN CORREGIDA
    const rutaImagen = (() => {
      if (!p.imagen) return "images/sin-imagen.jpg"; // si no tiene imagen
      let nombre = p.imagen.replaceAll("\\", "/"); // reemplaza barras invertidas
      if (nombre.startsWith("uploads/")) {
        nombre = nombre.replace("uploads/", "");
      }
      return `http://localhost:4000/uploads/${nombre}`;
    })();

    const subtotal = p.precio * item.cantidad;
    total += subtotal;

    return `
      <div class="item">
        <img src="${rutaImagen}" alt="${p.nombre}">
        <div>
          <h4>${p.nombre}</h4>
          <p>Cantidad: ${item.cantidad}</p>
          <p>Precio unitario: $${p.precio}</p>
          <p>Subtotal: $${subtotal}</p>
        </div>
      </div>
    `;
  }).join("");

  contenedor.innerHTML = `
    <h2>🧾 Ticket de compra</h2>
    <p><strong>Cliente:</strong> ${cliente}</p>
    <p><strong>Fecha:</strong> ${fecha}</p>
    <div>${detalles}</div>
    <h3>Total a abonar: $${totalCompra || total}</h3>
    <div class="botones-ticket">
      <button onclick="descargarPDF()">📄 Descargar Ticket en PDF</button>
      <button onclick="reiniciar()">🔄 Nueva compra</button>
    </div>
  `;

  await registrarVenta();
}

async function registrarVenta() {
  try {
    await fetch(API_VENTAS, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cliente, carrito })
    });
    console.log("✅ Venta registrada en la base de datos.");
  } catch (err) {
    console.error("❌ Error al registrar la venta:", err);
  }
}

function descargarPDF() {
  window.print();
}

function reiniciar() {
  localStorage.clear();
  window.location.href = "index.html";
}

generarTicket();
