// ========= TEMA OSCURO / CLARO =========

// Aplicar tema guardado
const temaGuardado = localStorage.getItem("tema") || "claro";
if (temaGuardado === "oscuro") {
 document.body.classList.add("tema-oscuro");
}

// Crear botón dinámico en el header
const botonTema = document.createElement("button");
botonTema.id = "btnTema";
// Usamos innerHTML para insertar el icono Lucide. 
// data-lucide="moon" para modo oscuro (cambiar a claro)
// data-lucide="sun" para modo claro (cambiar a oscuro)
botonTema.innerHTML = temaGuardado === "oscuro" ? '<span data-lucide="sun"></span>' : '<span data-lucide="moon"></span>';


function alternarTema() {
 document.body.classList.toggle("tema-oscuro");
 const esOscuro = document.body.classList.contains("tema-oscuro");
 localStorage.setItem("tema", esOscuro ? "oscuro" : "claro");
 
  // CAMBIO CLAVE: Actualizar el icono
 botonTema.innerHTML = esOscuro ? '<span data-lucide="sun"></span>' : '<span data-lucide="moon"></span>';
  
  // Si Lucide no renderiza automáticamente (depende de la librería), forzamos el renderizado.
  if (typeof lucide !== 'undefined' && lucide.createIcons) {
      lucide.createIcons();
  }
}

// Insertar el botón al header si existe
window.addEventListener("DOMContentLoaded", () => {
  // CAMBIO CLAVE: Buscar el nuevo contenedor de botones
  const buttonContainer = document.querySelector(".header-buttons");
  
  if (buttonContainer) {
    buttonContainer.appendChild(botonTema);
    botonTema.addEventListener("click", alternarTema);
      
      // Llamar al renderizado inicial de Lucide después de insertar el botón
      if (typeof lucide !== 'undefined' && lucide.createIcons) {
          lucide.createIcons();
      }
  }
});