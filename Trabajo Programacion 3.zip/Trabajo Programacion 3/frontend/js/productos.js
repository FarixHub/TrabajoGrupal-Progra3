//Carga los productos desde el backend y los muestra.
const API_URL = "http://localhost:4000/api/productos";
const contenedor = document.getElementById("productosContainer");

function chunkArray(array, chunkSize) {
    const results = [];
    let tempArray = [...array]; 
    while (tempArray.length) {
        results.push(tempArray.splice(0, chunkSize));
    }
    return results;
}

async function cargarProductos() {
    const res = await fetch(API_URL);
    const productos = await res.json();

    const categorias = [...new Set(productos.map((p) => p.categoria))];
    
    // LÓGICA DE DETECCIÓN DE PANTALLA
    // Usamos 1200px como punto de quiebre para el diseño de 5 cards.
    const SCREEN_BREAKPOINT = 1200; 
    const isSmallScreen = window.innerWidth < SCREEN_BREAKPOINT;

    // Define cuántas cards quieres por slide (3 para pantallas chicas, 5 para grandes)
    const CARDS_PER_SLIDE = isSmallScreen ? 3 : 5;
    
    // Define la clase de columna: col-4 para 3 items (12/3=4), col-1-5 para 5 items (20% de ancho, se requiere CSS personalizado)
    const colClass = isSmallScreen ? 'col-4' : 'col-1-5';
    // ----------------------------------------------------------------------

    contenedor.innerHTML = `
    <div class="container-fluid py-3"> ${categorias
        .map((cat, index) => {
            const categoriaProductos = productos.filter((p) => p.categoria === cat);
            // Agrupamos los productos en slides
            const slides = chunkArray(categoriaProductos, CARDS_PER_SLIDE);

            // Generamos un ID único para cada carrusel
            const carouselId = `carousel-${cat.toLowerCase().replace(/\s/g, '-')}`;

            return `
            <section class="mb-5"> 
                <h2 class="text-center mb-4 display-6 fw-bold">${cat.toUpperCase()}</h2>
            
                <div id="${carouselId}" class="carousel slide" data-bs-ride="false">
                    <div class="carousel-inner">
                        ${slides.map((slide, slideIndex) => `
                            <div class="carousel-item ${slideIndex === 0 ? 'active' : ''}">
                                <div class="row justify-content-center g-2">
                                    ${slide.map(p => `
                                        <div class="${colClass} d-flex">
                                            <div class="card h-100 border-0 product-card">
                                                <div class="img-wrapper"> 
                                                    <img src="${p.imagen.startsWith("http") ? p.imagen : "http://localhost:4000/uploads/" + p.imagen}" 
                                                         class="card-img-top" 
                                                         alt="${p.nombre}">
                                                </div> 
                                                <div class="card-body d-flex flex-column p-3">
                                                    <h5 class="card-title text-truncate fw-bold text-primary mb-2">${p.nombre}</h5>
                                                    <p class="card-text text-muted small mb-3 flex-grow-1 overflow-hidden" style="min-height: 45px;">${p.descripcion}</p>
                                                    <div class="mt-auto pt-2 border-top text-center">
                                                        <strong class="h4 text-danger d-block mb-2">$${p.precio}</strong>
                                                        <button class="btn btn-dark w-100 btn-md" 
                                                                onclick="agregarAlCarrito(${p.id})">
                                                            Añadir
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    `).join("")}
                                </div>
                            </div>
                        `).join("")}
                    </div>
                    
                    ${slides.length > 1 ? `
                        <button class="carousel-control-prev" type="button" data-bs-target="#${carouselId}" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#${carouselId}" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    ` : ''}

                </div>
            </section>
            `;
        })
        .join("")}
    </div> `;
}

function agregarAlCarrito(id) {
  const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
  const item = carrito.find((i) => i.id === id);
  if (item) {
    item.cantidad++;
  } else {
    carrito.push({ id, cantidad: 1 });
  }
  localStorage.setItem("carrito", JSON.stringify(carrito));
  alert("Producto agregado al carrito 🛒");
}

cargarProductos();
