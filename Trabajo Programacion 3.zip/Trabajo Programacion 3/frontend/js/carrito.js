//Maneja el carrito en localStorage.
const API_URL = "http://localhost:4000/api/productos";
const contenedor = document.getElementById("carritoContainer");
const totalSpan = document.getElementById("total");
let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

async function cargarCarrito() {
  const res = await fetch(API_URL);
  const productos = await res.json();
  let total = 0;

  contenedor.innerHTML = carrito.map(item => {
    const p = productos.find(prod => prod.id === item.id);
    if (!p) return "";

    // ✅ Ruta correcta para imágenes
    const rutaImagen = (() => {
      if (!p.imagen) return "images/sin-imagen.jpg";
      let nombre = p.imagen.replaceAll("\\", "/");
      if (nombre.startsWith("uploads/")) nombre = nombre.replace("uploads/", "");
      return `http://localhost:4000/uploads/${nombre}`;
    })();

    const subtotal = p.precio * item.cantidad;
    total += subtotal;

    return `
      <div class="item">
        <img src="${rutaImagen}" alt="${p.nombre}">
        <div>
          <h4>${p.nombre}</h4>
          <p>Precio unitario: $${p.precio}</p>
          <p>
            Cantidad: 
            <button onclick="cambiarCantidad(${p.id}, -1)">-</button>
            ${item.cantidad}
            <button onclick="cambiarCantidad(${p.id}, 1)">+</button>
          </p>
          <p>Subtotal: $${subtotal}</p>
        </div>
      </div>
    `;
  }).join("");

  totalSpan.textContent = `$${total}`;
  localStorage.setItem("totalCompra", total);
}

function cambiarCantidad(id, delta) {
  const index = carrito.findIndex(i => i.id === id);
  if (index >= 0) {
    carrito[index].cantidad += delta;
    if (carrito[index].cantidad <= 0) carrito.splice(index, 1);
  }
  localStorage.setItem("carrito", JSON.stringify(carrito));
  cargarCarrito();
}

function finalizarCompra() {
  if (carrito.length === 0) {
    alert("Tu carrito está vacío.");
    return;
  }
  // ✅ Guarda carrito y total antes de redirigir
  localStorage.setItem("carrito", JSON.stringify(carrito));
  window.location.href = "ticket.html";
}

cargarCarrito();
