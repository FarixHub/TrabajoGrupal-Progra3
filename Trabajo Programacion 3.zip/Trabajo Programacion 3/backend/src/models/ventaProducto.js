import { DataTypes } from "sequelize";
import sequelize from "../database.js";
import Venta from "./venta.js";
import Producto from "./producto.js";

const VentaProducto = sequelize.define("VentaProducto", {
  cantidad: {
    type: DataTypes.INTEGER,
    defaultValue: 1
  },
  subtotal: {
    type: DataTypes.FLOAT,
    allowNull: false
  }
});

// Relaciones N:M
Venta.belongsToMany(Producto, { through: VentaProducto });
Producto.belongsToMany(Venta, { through: VentaProducto });

export default VentaProducto;

