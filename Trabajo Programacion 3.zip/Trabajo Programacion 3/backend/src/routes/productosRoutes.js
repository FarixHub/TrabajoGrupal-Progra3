import express from "express";
import Producto from "../models/producto.js";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";

const router = express.Router();

// Configurar multer para subida de imágenes
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../../uploads"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ storage });

// 📌 OBTENER TODOS LOS PRODUCTOS (GET /)
router.get("/", async (req, res) => {
  try {
    const productos = await Producto.findAll({ where: { activo: true } });
    res.json(productos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 OBTENER UN PRODUCTO POR ID
router.get("/:id", async (req, res) => {
  try {
    const producto = await Producto.findByPk(req.params.id);
    if (!producto) {
      return res.status(404).json({ error: "Producto no encontrado" });
    }
    res.json(producto);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 CREAR UN NUEVO PRODUCTO (ABM - AGREGAR)
router.post("/", upload.single("imagen"), async (req, res) => {
  try {
    const { nombre, descripcion, precio, categoria } = req.body;

    if (!nombre || !precio || !categoria) {
      return res.status(400).json({ error: "Nombre, precio y categoría son requeridos" });
    }

    const nuevoProducto = await Producto.create({
      nombre,
      descripcion: descripcion || "",
      precio: parseFloat(precio),
      categoria,
      imagen: req.file ? req.file.filename : null,
      activo: true
    });

    res.status(201).json({ 
      mensaje: "Producto creado exitosamente", 
      producto: nuevoProducto 
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 ACTUALIZAR UN PRODUCTO (ABM - MODIFICAR)
router.put("/:id", upload.single("imagen"), async (req, res) => {
  try {
    const producto = await Producto.findByPk(req.params.id);
    if (!producto) {
      return res.status(404).json({ error: "Producto no encontrado" });
    }

    const { nombre, descripcion, precio, categoria, activo } = req.body;

    if (nombre) producto.nombre = nombre;
    if (descripcion) producto.descripcion = descripcion;
    if (precio) producto.precio = parseFloat(precio);
    if (categoria) producto.categoria = categoria;
    if (activo !== undefined) producto.activo = activo === "true" || activo === true;
    if (req.file) producto.imagen = req.file.filename;

    await producto.save();

    res.json({ 
      mensaje: "Producto actualizado exitosamente", 
      producto 
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 ELIMINAR UN PRODUCTO (ABM - ELIMINAR) - Eliminación lógica
router.delete("/:id", async (req, res) => {
  try {
    const producto = await Producto.findByPk(req.params.id);
    if (!producto) {
      return res.status(404).json({ error: "Producto no encontrado" });
    }

    producto.activo = false;
    await producto.save();

    res.json({ 
      mensaje: "Producto eliminado exitosamente", 
      producto 
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 ELIMINAR PERMANENTEMENTE UN PRODUCTO
router.delete("/:id/permanente", async (req, res) => {
  try {
    const producto = await Producto.findByPk(req.params.id);
    if (!producto) {
      return res.status(404).json({ error: "Producto no encontrado" });
    }

    await producto.destroy();

    res.json({ 
      mensaje: "Producto eliminado permanentemente" 
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 LISTAR TODOS LOS PRODUCTOS (incluyendo inactivos) - Solo admin
router.get("/admin/todos", async (req, res) => {
  try {
    const productos = await Producto.findAll();
    res.json(productos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;