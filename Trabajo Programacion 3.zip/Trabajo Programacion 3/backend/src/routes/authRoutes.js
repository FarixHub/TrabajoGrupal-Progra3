import express from "express";
import bcrypt from "bcryptjs";
import Usuario from "../models/usuario.js";

const router = express.Router();

// Mostrar login
router.get("/login", (req, res) => {
  res.render("login", { error: null });
});

// Iniciar sesión
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const user = await Usuario.findOne({ where: { email } });
  if (!user) return res.render("login", { error: "Usuario no encontrado" });

  const coincide = await bcrypt.compare(password, user.password);
  if (!coincide) return res.render("login", { error: "Contraseña incorrecta" });

  req.session.usuario = user;
  res.redirect("/admin/dashboard");
});

// Cerrar sesión
router.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/admin/login");
  });
});

export default router;
