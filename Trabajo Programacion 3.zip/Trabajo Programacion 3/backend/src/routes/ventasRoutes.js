import express from "express";
import Venta from "../models/venta.js";
import Producto from "../models/producto.js";

const router = express.Router();

// Registrar venta
router.post("/", async (req, res) => {
  try {
    const { cliente, carrito } = req.body;

    if (!cliente || !carrito || carrito.length === 0)
      return res.status(400).json({ error: "Datos incompletos" });

    let total = 0;
    const productos = await Producto.findAll();

    // Crear venta
    const venta = await Venta.create({ cliente, total: 0 });

    for (const item of carrito) {
      const p = productos.find(prod => prod.id === item.id);
      if (!p) continue;

      const subtotal = p.precio * item.cantidad;
      total += subtotal;

      await venta.addProducto(p, {
        through: { cantidad: item.cantidad, subtotal }
      });
    }

    venta.total = total;
    await venta.save();

    res.json({ mensaje: "Venta registrada correctamente", venta });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Listar las 10 ventas más caras
router.get("/top-ventas", async (req, res) => {
  const ventas = await Venta.findAll({
    order: [["total", "DESC"]],
    limit: 10
  });
  res.json(ventas);
});

// Listar los 10 productos más vendidos
router.get("/top-productos", async (req, res) => {
  const [result] = await Producto.sequelize.query(`
    SELECT p.nombre, SUM(vp.cantidad) AS total_vendidos
    FROM VentaProductos vp
    JOIN Productos p ON vp.ProductoId = p.id
    GROUP BY p.id
    ORDER BY total_vendidos DESC
    LIMIT 10;
  `);
  res.json(result);
});

export default router;
