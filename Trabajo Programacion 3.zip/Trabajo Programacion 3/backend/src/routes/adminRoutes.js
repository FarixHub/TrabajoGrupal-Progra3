import express from "express";
import Producto from "../models/producto.js";
import Venta from "../models/venta.js";
import sequelize from "../database.js";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";

const router = express.Router();

// Configurar multer para subida de imágenes
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../../uploads"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

// Middleware para verificar si está logueado
function verificarLogin(req, res, next) {
  if (!req.session.usuario) return res.redirect("/admin/login");
  next();
}

// 🏠 DASHBOARD
router.get("/dashboard", verificarLogin, async (req, res) => {
  try {
    const productos = await Producto.findAll();

    // Totales
    const totalProductos = await Producto.count();
    const totalVentas = await Venta.count();
    const sumaVentas = await Venta.sum("total") || 0;

    // Producto más vendido
    const [masVendido] = await sequelize.query(`
      SELECT p.id, p.nombre, p.imagen, SUM(vp.cantidad) AS cantidad_vendida
      FROM VentaProductos vp
      JOIN Productos p ON vp.ProductoId = p.id
      GROUP BY p.id
      ORDER BY cantidad_vendida DESC
      LIMIT 1;
    `);

    res.render("dashboard", {
      productos,
      totalProductos,
      totalVentas,
      sumaVentas,
      masVendido: masVendido[0] || null
    });
  } catch (err) {
    res.status(500).send("Error al cargar dashboard: " + err.message);
  }
});

// ➕ NUEVO PRODUCTO - Mostrar formulario
router.get("/nuevo", verificarLogin, (req, res) => {
  res.render("producto-form", { producto: null, error: null });
});

// ➕ CREAR PRODUCTO - Procesar formulario
router.post("/nuevo", verificarLogin, upload.single("imagen"), async (req, res) => {
  try {
    const { nombre, descripcion, precio, categoria } = req.body;

    if (!nombre || !precio || !categoria) {
      return res.render("producto-form", {
        producto: req.body,
        error: "⚠️ Nombre, precio y categoría son requeridos"
      });
    }

    const nuevoProducto = await Producto.create({
      nombre,
      descripcion: descripcion || "",
      precio: parseFloat(precio),
      categoria,
      imagen: req.file ? req.file.filename : null,
      activo: true
    });

    console.log("Producto creado:", nuevoProducto);
    console.log("Producto Res:", res);
    console.log("Producto Req:", req );

    res.redirect("/admin/dashboard?success=Producto%20agregado%20exitosamente");
  } catch (err) {
    console.error("Error al crear producto:", err);
    res.render("producto-form", {
      producto: req.body,
      error: "❌ Error al crear el producto"
    });
  }
});

// ✏️ EDITAR PRODUCTO - Mostrar formulario
router.get("/editar/:id", verificarLogin, async (req, res) => {
  try {
    const producto = await Producto.findByPk(req.params.id);
    
    if (!producto) {
      return res.status(404).send("Producto no encontrado");
    }

    res.render("producto-form", { producto, error: null });
  } catch (err) {
    console.error("Error al cargar producto:", err);
    res.status(500).send("Error al cargar el producto");
  }
});

// ✏️ ACTUALIZAR PRODUCTO - Procesar formulario
router.post("/editar/:id", verificarLogin, upload.single("imagen"), async (req, res) => {
  try {
    const { nombre, descripcion, precio, categoria } = req.body;
    const producto = await Producto.findByPk(req.params.id);

    if (!producto) {
      return res.status(404).send("Producto no encontrado");
    }

    if (!nombre || !precio || !categoria) {
      return res.render("producto-form", {
        producto,
        error: "⚠️ Nombre, precio y categoría son requeridos"
      });
    }

    producto.nombre = nombre;
    producto.descripcion = descripcion || "";
    producto.precio = parseFloat(precio);
    producto.categoria = categoria;
    if (req.file) {
      producto.imagen = req.file.filename;
    }

    await producto.save();

    res.redirect("/admin/dashboard?success=Producto%20actualizado%20exitosamente");
  } catch (err) {
    console.error("Error al actualizar producto:", err);
    res.render("producto-form", {
      producto: req.body,
      error: "❌ Error al actualizar el producto"
    });
  }
});

// 🗑️ ELIMINAR PRODUCTO
router.get("/baja/:id", verificarLogin, async (req, res) => {
  try {
    const producto = await Producto.findByPk(req.params.id);

    if (!producto) {
      return res.status(404).send("Producto no encontrado");
    }

    // Eliminación lógica
    producto.activo = !producto.activo;
    await producto.save();

    //alert("Producto: ",producto.nombre ," modificado exitosamente a ", producto.activo ? 'Activo' : 'Inactivo');

    res.redirect("/admin/dashboard?success=Producto%20eliminado%20exitosamente");
  } catch (err) {
    console.error("Error al eliminar producto:", err);
    res.status(500).send("Error al eliminar el producto");
  }
});

// 🗑️ ELIMINAR PRODUCTO
router.delete("/eliminar/:id", verificarLogin, async (req, res) => {
    try {
        const producto = await Producto.findByPk(req.params.id);
        
        if (!producto) {
            return res.status(404).send("Producto no encontrado");
        }
        
        // Asegúrate de que estás ejecutando la eliminación real
        await producto.destroy(); 

        // Redirige al dashboard después de la eliminación exitosa
        res.redirect("/admin/dashboard?success=Producto%20eliminado%20exitosamente");
    } catch (err) {
        console.error("Error al eliminar producto:", err);
        res.status(500).send("Error al eliminar el producto");
    }
});


// 📊 REGISTROS
router.get("/registros", verificarLogin, async (req, res) => {
  try {
    const ventas = await Venta.findAll({
      order: [["total", "DESC"]],
      limit: 10
    });

    const [productos] = await sequelize.query(`
      SELECT p.nombre, SUM(vp.cantidad) AS total_vendidos
      FROM VentaProductos vp
      JOIN Productos p ON vp.ProductoId = p.id
      GROUP BY p.id
      ORDER BY total_vendidos DESC
      LIMIT 10;
    `);

    res.render("registros", { ventas, productos });
  } catch (err) {
    res.status(500).send("Error al obtener registros: " + err.message);
  }
});

export default router;
