// Levanta el servidor y define rutas API.
import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import methodOverride from "method-override"; // 1. Importar method-override
import ventasRoutes from "./routes/ventasRoutes.js";
import session from "express-session";
import sequelize from "./database.js";
import Producto from "./models/producto.js";
import Usuario from "./models/usuario.js";
import "./models/ventaProducto.js";
import adminRoutes from "./routes/adminRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import bcrypt from "bcryptjs";
import path from "path";
import { fileURLToPath } from "url";

// 🔧 Define __dirname para ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(path.resolve(__dirname, "../uploads")));

// 2. Configurar method-override
// Esto permite que las peticiones POST enviadas desde un formulario
// puedan ser interpretadas como DELETE, PUT o PATCH si incluyen el query
// ?_method=DELETE o un campo oculto con name="_method".
app.use(methodOverride("_method"));

// Configurar sesiones
app.use(session({
    secret: "facu-tp-secret",
    resave: false,
    saveUninitialized: false
}));

// EJS
app.set("view engine", "ejs");
app.set("views", "./src/views");

// Rutas frontend API
app.get("/", (req, res) => res.send("Servidor backend funcionando 🚀"));
app.get("/api/productos", async (req, res) => {
    const productos = await Producto.findAll({ where: { activo: true } });
    res.json(productos);
});
app.get("/api/productos/:id", async (req, res) => {
    const producto = await Producto.findByPk(req.params.id);
    if (!producto) return res.status(404).json({ error: "Producto no encontrado" });
    res.json(producto);
});

// Rutas admin
app.use("/admin", authRoutes);
app.use("/admin", adminRoutes);
app.use("/api/ventas", ventasRoutes);

// Sincronizar BD
await sequelize.sync({ alter: true });

// Crear usuario admin por primera vez (una sola vez)
const existe = await Usuario.findOne({ where: { email: "admin@admin.com" } });
if (!existe) {
    const hash = await bcrypt.hash("1234", 10);
    await Usuario.create({ nombre: "Administrador", email: "admin@admin.com", password: hash });
    console.log("✅ Usuario admin creado: admin@admin.com / 1234");
}

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Servidor en puerto ${PORT}`));