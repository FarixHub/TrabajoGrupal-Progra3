//Sirve para cargar los productos iniciales (Remeras y Pantalones).
import sequelize from './database.js';
import { DataTypes } from 'sequelize';

const Producto = sequelize.define('producto', {
  nombre: DataTypes.STRING,
  descripcion: DataTypes.TEXT,
  precio: DataTypes.DECIMAL(10, 2),
  imagen: DataTypes.STRING,
  categoria: DataTypes.STRING,
  activo: { type: DataTypes.BOOLEAN, defaultValue: true }
});

async function seed() {
  try {
    await sequelize.authenticate();
    await sequelize.sync();

    process.exit(0);
  } catch (err) {
    console.error("❌ Error al cargar seed:", err);
    process.exit(1);
  }
}

seed();
